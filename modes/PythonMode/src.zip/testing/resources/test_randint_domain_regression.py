import random
assert random.randint(-0, 0) == 0
print 'OK'
exit()